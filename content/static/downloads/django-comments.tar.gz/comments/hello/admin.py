from django.contrib import admin
from hello.models import Topic

admin.site.register(Topic)
