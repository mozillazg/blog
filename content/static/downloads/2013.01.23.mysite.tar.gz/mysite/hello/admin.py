#!/usr/bin/env python
# -*- coding: utf-8 -*-

from django.contrib import admin
from hello.models import Category

admin.site.register(Category)
